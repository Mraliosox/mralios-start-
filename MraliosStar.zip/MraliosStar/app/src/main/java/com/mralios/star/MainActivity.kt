package com.mralios.star

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.RgbFilter
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.io.File
import kotlin.concurrent.thread

enum class VideoFx(val label: String) {
    NONE("بدون مؤثر"),
    BW("أبيض وأسود"),
    INVERT("عكس الألوان"),
    BRIGHT("سطوع"),
    CONTRAST("تباين"),
}

@androidx.annotation.OptIn(UnstableApi::class)
fun VideoFx.toEffects(): List<Effect> = when (this) {
    VideoFx.NONE -> emptyList()
    VideoFx.BW -> listOf(RgbFilter.createGrayscaleFilter())
    VideoFx.INVERT -> listOf(RgbFilter.createInvertedFilter())
    VideoFx.BRIGHT -> listOf(Brightness(0.25f))
    VideoFx.CONTRAST -> listOf(Contrast(0.5f))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    EditorScreen()
                }
            }
        }
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun EditorScreen() {
    val context = LocalContext.current

    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var musicUri by remember { mutableStateOf<Uri?>(null) }
    var fx by remember { mutableStateOf(VideoFx.NONE) }
    var exporting by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var transformer by remember { mutableStateOf<Transformer?>(null) }

    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    // المعاينة: تحديث الفيديو والمؤثر
    LaunchedEffect(videoUri) {
        videoUri?.let {
            player.setMediaItem(MediaItem.fromUri(it))
            player.prepare()
            player.playWhenReady = true
        }
    }
    LaunchedEffect(fx) { player.setVideoEffects(fx.toEffects()) }

    // متابعة نسبة التصدير
    LaunchedEffect(exporting) {
        while (exporting) {
            val holder = ProgressHolder()
            val state = transformer?.getProgress(holder)
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                progress = holder.progress / 100f
            }
            delay(300)
        }
    }

    val pickVideo = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) videoUri = uri }

    val pickMusic = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) musicUri = uri }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Mralios Star", style = MaterialTheme.typography.headlineMedium)

        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp),
            factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                pickVideo.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                )
            }) { Text(if (videoUri == null) "اختر فيديو" else "تغيير الفيديو") }

            OutlinedButton(onClick = { pickMusic.launch(arrayOf("audio/*")) }) {
                Text(if (musicUri == null) "اختر موسيقى" else "تغيير الموسيقى")
            }
        }

        Text("المؤثرات", style = MaterialTheme.typography.titleMedium)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            VideoFx.entries.forEach { item ->
                FilterChip(
                    selected = fx == item,
                    onClick = { fx = item },
                    label = { Text(item.label) },
                )
            }
        }

        if (exporting) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth(),
            )
            Text("جارٍ التصدير… ${(progress * 100).toInt()}%")
        }

        Button(
            enabled = videoUri != null && !exporting,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val video = videoUri ?: return@Button
                exporting = true
                progress = 0f
                transformer = exportVideo(
                    context = context,
                    video = video,
                    music = musicUri,
                    fx = fx,
                    onFinished = { error ->
                        exporting = false
                        Toast.makeText(
                            context,
                            error ?: "تم الحفظ في المعرض (Movies/MraliosStar)",
                            Toast.LENGTH_LONG,
                        ).show()
                    },
                )
            },
        ) { Text("تصدير الفيديو") }
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
fun exportVideo(
    context: Context,
    video: Uri,
    music: Uri?,
    fx: VideoFx,
    onFinished: (error: String?) -> Unit,
): Transformer {
    val videoItem = EditedMediaItem.Builder(MediaItem.fromUri(video))
        .setEffects(Effects(emptyList(), fx.toEffects()))
        .setRemoveAudio(music != null) // نستبدل صوت الفيديو بالموسيقى
        .build()

    val sequences = mutableListOf(EditedMediaItemSequence(listOf(videoItem)))

    if (music != null) {
        val durationMs = videoDurationMs(context, video)
        val musicMediaItem = MediaItem.Builder()
            .setUri(music)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setEndPositionMs(durationMs)
                    .build()
            )
            .build()
        val musicItem = EditedMediaItem.Builder(musicMediaItem)
            .setRemoveVideo(true)
            .build()
        sequences += EditedMediaItemSequence(listOf(musicItem))
    }

    val composition = Composition.Builder(sequences).build()
    val output = File(context.cacheDir, "export_${System.currentTimeMillis()}.mp4")

    val transformer = Transformer.Builder(context)
        .addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                thread {
                    val ok = saveToGallery(context, output)
                    output.delete()
                    android.os.Handler(context.mainLooper).post {
                        onFinished(if (ok) null else "تعذر الحفظ في المعرض")
                    }
                }
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException,
            ) {
                onFinished("فشل التصدير: ${exportException.message}")
            }
        })
        .build()

    transformer.start(composition, output.absolutePath)
    return transformer
}

fun videoDurationMs(context: Context, uri: Uri): Long {
    val retriever = MediaMetadataRetriever()
    return try {
        retriever.setDataSource(context, uri)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            ?.toLongOrNull() ?: 0L
    } finally {
        retriever.release()
    }
}

fun saveToGallery(context: Context, file: File): Boolean {
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "MraliosStar_${System.currentTimeMillis()}.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MraliosStar")
    }
    val resolver = context.contentResolver
    val target = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return false
    return try {
        resolver.openOutputStream(target)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        }
        true
    } catch (e: Exception) {
        resolver.delete(target, null, null)
        false
    }
}
